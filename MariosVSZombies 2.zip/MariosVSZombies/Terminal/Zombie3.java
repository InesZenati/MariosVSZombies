public class Zombie3 extends Zombie{
    public Zombie3(int v){
        super("SuperZombie",100,v,new Information(2,0,-1,-1,10));
    }
    
}
