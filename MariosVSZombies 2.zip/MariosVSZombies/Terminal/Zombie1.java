public class Zombie1 extends Zombie {
    public Zombie1( int v){
        super("ZombieSimple",10,v,new Information(6,0,-1,-1,10));
    }
    

}